#pragma warning(disable:4996)
#pragma comment(lib,"ws2_32.lib")
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <time.h>
#include <process.h> 
#define TRUE 1
#define FALSE 0
#define BUF_SIZE 103
#define MSG_SIZE 100
#define NAME_SIZE 20
#define MAX_USER 6
#define MAX_ROOM_SIZE 2
#define MAX_MAFIA 2

enum Role { Null, Mafia1, Mafia2, Citizen };
int RoomBuf[MAX_ROOM_SIZE];
char RoomMsg[MSG_SIZE];
char GameEchoBuf[6][MSG_SIZE + 1];      //ä�� ������ 6������ ����.
char UserBuf[6][MSG_SIZE + 1];
char msg[MSG_SIZE]; // ���۹� �޴� �޼���
int currtime, confTime, voteTime, personalRole, personalIdx, anotherMafiaIdx, roomNum;// Int
int mafia, mafiaCanUseAbility, checkMafiaAbilityUse, checkConfTime, checkVoteTime, checkAlive, checkMorning, gameStart, gameEnd, roomSel; // Bool
int deathIdx[MAX_USER];
CRITICAL_SECTION ChatCS1, ChatCS2;

void ErrorHandling(char* msg);
unsigned WINAPI SendMsg(void* arg);
unsigned WINAPI RecvMsg(void* arg);
unsigned WINAPI GameManager(void* arg);
void GameChatWindow();
void GameChatClear();
void RoomSelectWindow();
void gotoxy(int x, int y);
void setMessage(char* recvMsg, char* user);
char* manufactureSendMsg(char* sendMsg, char* result);
#pragma once